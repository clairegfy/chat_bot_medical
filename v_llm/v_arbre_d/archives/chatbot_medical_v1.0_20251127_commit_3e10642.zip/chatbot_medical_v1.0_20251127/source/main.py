import re
import unicodedata
import readchar
from datetime import datetime
import json
import os
from rapidfuzz import fuzz, process

# seuils de grossesses en semaine
GROSSESSE_EARLY_THRESHOLD = 4  
GROSSESSE_FIRST_TRIMESTER = 12  
GROSSESSE_MAX_WEEKS = 45

# si jamais l'input utilisateur n'est pas un int -> on demande si il se situe dans ces 3 catégories 
# < 3, <8 ou <16 semaines
GROSSESSE_EXAMPLE_LT4 = 3
GROSSESSE_EXAMPLE_4_12 = 8
GROSSESSE_EXAMPLE_GT12 = 16

# Seuils pour fuzzy matching (scores 0-100)
FUZZY_THRESHOLD_EXACT = 90      # Seuil pour correspondance quasi-exacte
FUZZY_THRESHOLD_PARTIAL = 75    # Seuil pour correspondance partielle
FUZZY_THRESHOLD_KEYWORD = 80    # Seuil pour mots-clés de population

# Dictionnaire d'acronymes médicaux courants
MEDICAL_ACRONYMS = {
    # Anatomie
    "fid": "fosse iliaque droite",
    "fig": "fosse iliaque gauche",
    "fid droite": "fosse iliaque droite",
    "fig gauche": "fosse iliaque gauche",
    
    # Examens
    "irm": "imagerie par résonance magnétique",
    "tdm": "tomodensitométrie",
    "ct": "scanner",
    "rx": "radiographie",
    "echo": "échographie",
    "us": "échographie",
    
    # Pathologies thorax
    "ep": "embolie pulmonaire",
    "oap": "œdème aigu pulmonaire",
    "bpco": "bronchopneumopathie chronique obstructive",
    "htap": "hypertension artérielle pulmonaire",
    
    # Pathologies digestif
    "rgo": "reflux gastro-œsophagien",
    "mici": "maladie inflammatoire chronique intestinale",
    "ulh": "ulcère gastro-duodénal",
    
    # Symptômes
    "sad": "syndrome abdominal aigu",
    "sca": "syndrome coronarien aigu",
    "avc": "accident vasculaire cérébral",
    "ait": "accident ischémique transitoire",
    
    # Anatomie générale
    "hcd": "hypocondre droit",
    "hcg": "hypocondre gauche",
    "epigastre": "épigastre",
    "hypogastre": "hypogastre",
}

def _expand_acronyms(texte):
    """
    Remplace les acronymes médicaux par leur forme complète.
    
    Args:
        texte: Texte contenant possiblement des acronymes
    
    Returns:
        Texte avec acronymes expansés
    
    Exemple:
        "douleur FID" → "douleur fosse iliaque droite FID"
        (garde l'acronyme original pour compatibilité)
    """
    texte_expanded = texte
    texte_lower = texte.lower()
    
    # Chercher chaque acronyme dans le texte
    for acronym, full_form in MEDICAL_ACRONYMS.items():
        # Pattern pour trouver l'acronyme en tant que mot complet
        pattern = r'\b' + re.escape(acronym) + r'\b'
        
        # Si l'acronyme est trouvé
        if re.search(pattern, texte_lower):
            # Ajouter la forme complète après l'acronyme (sans le remplacer)
            # Exemple: "FID" devient "FID (fosse iliaque droite)"
            replacement = f"{acronym} ({full_form})"
            texte_expanded = re.sub(
                pattern, 
                replacement, 
                texte_expanded, 
                flags=re.IGNORECASE
            )
    
    return texte_expanded


def _fuzzy_match_symptom(texte_norm, symptom_label, threshold=FUZZY_THRESHOLD_PARTIAL):
    """
    Vérifie si un symptôme est présent dans le texte avec fuzzy matching.
    
    Args:
        texte_norm: Texte normalisé (minuscules, sans accents)
        symptom_label: Label du symptôme à chercher
        threshold: Seuil de similarité (0-100)
    
    Returns:
        (matched: bool, score: float)
    """
    symptom_norm = _normalize_text(symptom_label)
    
    # Qualificatifs temporels/critiques à respecter strictement
    # Si le symptôme contient un de ces mots, le texte DOIT aussi le contenir
    critical_qualifiers = ['aigu', 'aigue', 'aigues', 'aigus', 
                          'chronique', 'chroniques',
                          'recurrent', 'recurrente', 'recurrentes', 'recurrents']
    
    # Vérifier si le symptôme contient un qualificatif critique
    symptom_has_qualifier = None
    for qual in critical_qualifiers:
        if re.search(r'\b' + qual + r'\b', symptom_norm):
            symptom_has_qualifier = qual
            break
    
    # Si le symptôme a un qualificatif critique, vérifier qu'il est aussi dans le texte
    if symptom_has_qualifier:
        if not re.search(r'\b' + symptom_has_qualifier + r'\b', texte_norm):
            # Le qualificatif n'est pas dans le texte : pas de match
            return False, 0
    
    # Méthode 1: Correspondance exacte (rapide)
    if symptom_norm in texte_norm:
        return True, 100
    
    # Méthode 2: Fuzzy matching sur phrases
    # Découper le texte en segments (phrases/morceaux)
    segments = re.split(r'[,;.]', texte_norm)
    segments = [s.strip() for s in segments if s.strip()]
    
    # Chercher le meilleur match
    best_score = 0
    for segment in segments:
        # Token sort ratio: insensible à l'ordre des mots
        score = fuzz.token_sort_ratio(symptom_norm, segment)
        best_score = max(best_score, score)
        
        # Si score très élevé, pas besoin de continuer
        if score >= FUZZY_THRESHOLD_EXACT:
            return True, score
    
    # Méthode 3: Partial ratio sur le texte complet (pour symptômes courts)
    partial_score = fuzz.partial_ratio(symptom_norm, texte_norm)
    best_score = max(best_score, partial_score)
    
    return best_score >= threshold, best_score


def analyse_texte_medical(texte):
    """Analyse le texte libre du médecin pour extraire les informations détectées.

    Améliorations :
    - expansion des acronymes médicaux (FID → fosse iliaque droite)
    - normalisation ASCII (suppression des accents) pour faire des recherches plus robustes,
    - utilisation de motifs avec bornes de mots et groupes nommés,
    - contrôles de plausibilité sur les valeurs numériques extraites.
    """
    # Étape 1: Expanser les acronymes médicaux
    texte_expanded = _expand_acronyms(texte)
    
    # Étape 2: Normaliser le texte pour les recherches : enlever les accents et travailler en ascii minuscule
    t_norm = unicodedata.normalize("NFKD", texte_expanded)
    t_norm = t_norm.encode("ascii", "ignore").decode("ascii").lower()

    # Précompiler patterns
    age_re = re.compile(r"\b(?P<age>\d{1,3})\s*ans?\b")
    preg_detect_re = re.compile(r"\b(?:enceinte|grossesse|gestation)\b")
    sem_re = re.compile(r"\b(?:enceinte|grossesse).*?(?P<weeks>\d{1,2})\s*(?:sem(?:aines?)?|sa|semaine)\b")
    mois_re = re.compile(r"\b(?:enceinte|grossesse).*?(?P<months>\d{1,2})\s*mois\b")

    # Age
    age_match = age_re.search(t_norm)
    age = int(age_match.group('age')) if age_match else None
    if age is not None and not (0 <= age <= 120):
        age = None

    # Détection automatique de la population basée sur l'âge
    population = None
    if age is not None:
        if age < 18:
            population = "enfant"
        elif 18 <= age < 65:
            population = "adulte"
        else:
            population = "personne_agee"
    
    # Detection explicite des mots-clés (priorité sur l'âge automatique)
    # Les mots-clés permettent de détecter la population même sans âge explicite
    # Utilise regex ET fuzzy matching pour plus de robustesse
    
    # Mots-clés de population
    keywords_enfant = ["enfant", "pediatrique", "nourrisson", "bebe", "nouveau-ne", "adolescent"]
    keywords_adulte = ["adulte", "jeune adulte"]
    keywords_agee = ["personne agee", "personne âgée", "senior", "geriatrique"]
    
    # Vérifier avec regex d'abord (rapide)
    if re.search(r"\b(?:enfant|pediatr\w*|nourrisson|bebe|nouveau[- ]?ne|adolescent)\b", t_norm):
        population = "enfant"
    elif re.search(r"\b(?:adulte|jeune adulte)\b", t_norm):
        population = "adulte"
    elif re.search(r"\b(?:personne agee|age[e]?|senior|geriatr\w*)\b", t_norm):
        population = "personne_agee"
    else:
        # Fuzzy matching en fallback pour typos ou variations
        best_match = None
        best_score = 0
        best_category = None
        
        for keyword in keywords_enfant:
            score = fuzz.partial_ratio(_normalize_text(keyword), t_norm)
            if score > best_score:
                best_score = score
                best_match = keyword
                best_category = "enfant"
        
        for keyword in keywords_adulte:
            score = fuzz.partial_ratio(_normalize_text(keyword), t_norm)
            if score > best_score:
                best_score = score
                best_match = keyword
                best_category = "adulte"
        
        for keyword in keywords_agee:
            score = fuzz.partial_ratio(_normalize_text(keyword), t_norm)
            if score > best_score:
                best_score = score
                best_match = keyword
                best_category = "personne_agee"
        
        # Appliquer si score suffisant
        if best_score >= FUZZY_THRESHOLD_KEYWORD and best_category:
            population = best_category

    # detection du sexe
    if re.search(r"\bpatiente\b", t_norm):
        sexe = "f"
    elif re.search(r"\bpatient\b", t_norm):
        sexe = "m"
    else:
        sexe = None

    # Détection grossesse et extraction durée
    grossesse_detectee = bool(preg_detect_re.search(t_norm))
    sem_match = sem_re.search(t_norm)
    mois_match = mois_re.search(t_norm)
    semaines = None
    if sem_match:
        try:
            semaines = int(sem_match.group('weeks'))
        except (ValueError, TypeError):
            semaines = None
    elif mois_match:
        try:
            mois = int(mois_match.group('months'))
            semaines = mois * 4
        except (ValueError, TypeError):
            semaines = None
    if semaines is not None and not (0 <= semaines <= 45):
        semaines = None

    # Détections binaires (patterns ascii simplifiés)
    return {
        "age": age,
        "population": population,
        "sexe": sexe,
        "grossesse": grossesse_detectee,
        "grossesse_sem": semaines,
    # fièvre / fébrile / febrile
    "fievre": bool(re.search(r"\b(?:fievre|febrile|febr|fiev)\b", t_norm)),
    # détecte 'brutal', 'brutale', 'brutales' et l'expression 'coup de tonnerre'
    "brutale": bool(re.search(r"\b(?:brutal\w*|coup de tonnerre)\b", t_norm)),
    # déficit moteur / paralysie / paresie / hémiplégie / troubles sensitifs
    "deficit": bool(re.search(r"\b(?:deficit|deficitaire|paralys(?:ie|is)?|paresi(?:e)?|hemipleg(?:ie)?|trouble moteur|trouble sensitif)\b", t_norm)),
    # oncologie / cancer / tumeur / métastase
    "oncologique": bool(re.search(r"\b(?:cancer|oncolog|tumeur|metast)\b", t_norm)),
    # chirurgie, opératoire, matériel, prothèse, ostéosynthèse, postop
    "chirurgie": bool(re.search(r"\b(?:chirurg|oper(?:at(?:ion|oire))?|materiel|prothese|osteosynth|postop|postoperatoire)\b", t_norm)),
    # pacemaker / pace-maker / stimulateur
    "pacemaker": bool(re.search(r"\b(?:pace[- _]?maker|pacemaker|stimulateur)\b", t_norm)),
    # claustrophobie*
    "claustrophobie": bool(re.search(r"\bclaustro\w*\b", t_norm)),
    # vertige / vertiges
    "vertige": bool(re.search(r"\bvertig\w*\b", t_norm))
    }

def afficher_contraindications(f, exam_entry=None):
    """Affiche les rappels en style fluide."""
    text = get_contraindications_text(f, exam_entry)
    if text:  # Afficher seulement si des remarques existent
        print(text)


def get_contraindications_text(f, exam_entry=None):
    """Retourne le texte des remarques/contre-indications pour affichage et export.
    
    Args:
        f: dictionnaire des informations patient
        exam_entry: entrée JSON de l'examen recommandé (optionnel, pour filtrer les remarques pertinentes)
    
    Returns:
        str: Texte des remarques, ou chaîne vide si aucune remarque pertinente
    """
    lines = []
    
    # Extraire les propriétés de l'examen si disponibles
    is_ionisant = exam_entry.get("ionisant", True) if exam_entry else True  # par défaut True (prudent)
    requires_contrast = exam_entry.get("requires_contrast", True) if exam_entry else True
    
    # Remarques spécifiques à la grossesse (seulement si examen ionisant)
    if is_ionisant and f["sexe"] == "f" and (not f["age"] or f["age"] < 50):
        if f.get("grossesse_sem") and f.get("grossesse_sem") < 4:
            lines.append("• Le scanner est strictement contre-indiqué pour une grossesse débutante (<4 semaines).")
        elif f.get("grossesse"):
            # Grossesse confirmée : pas besoin de test
            lines.append(f"• Grossesse confirmée ({f.get('grossesse_sem', 'durée précisée')} SA) : précautions d'irradiation à respecter.")
        else:
            # Pas de grossesse connue : recommander le test
            lines.append("• Chez les femmes de moins de 50 ans, un test de grossesse est recommandé avant tout examen radiologique.")
    
    # Remarques sur l'injection (seulement si l'examen nécessite une injection)
    if requires_contrast:
        lines.append("• Chez les patients de plus de 60 ans ou ayant des antécédents rénaux, un dosage de la créatinine est nécessaire avant injection de produit de contraste.")
        lines.append("• En cas d'allergie, signaler toute réaction préalable, mais les allergies aux crustacés ou à la Bétadine ne constituent pas une contre-indication au scanner iodé.")
    
    # Retourner vide si aucune remarque, sinon retourner avec en-tête
    if not lines:
        return ""
    
    return "Remarques complémentaires :\n" + "\n".join(lines)


def generer_ordonnance(f, texte_initial, decision, contraindications_text):
    """Génère le contenu d'une ordonnance médicale au format français.
    
    Args:
        f: dictionnaire des informations patient et cliniques
        texte_initial: texte libre du médecin
        decision: recommandation d'imagerie
        contraindications_text: texte des contre-indications
    
    Returns:
        str: contenu formaté de l'ordonnance
    """
    now = datetime.now()
    
    # En-tête de l'ordonnance
    ordonnance = []
    ordonnance.append("=" * 80)
    ordonnance.append(" " * 28 + "ORDONNANCE MÉDICALE")
    ordonnance.append("=" * 80)
    ordonnance.append("")
    
    # Informations du praticien (à personnaliser selon les besoins)
    ordonnance.append("Dr. [NOM DU MÉDECIN]")
    ordonnance.append("[Spécialité]")
    ordonnance.append("[Adresse du cabinet]")
    ordonnance.append("[Code postal et ville]")
    ordonnance.append("Tél : [Numéro de téléphone]")
    ordonnance.append("N° RPPS : [Numéro RPPS]")
    ordonnance.append("")
    ordonnance.append(f"Date : {now.strftime('%d/%m/%Y')}")
    ordonnance.append(f"Heure : {now.strftime('%H:%M')}")
    ordonnance.append("")
    ordonnance.append("-" * 80)
    ordonnance.append("")
    
    # Informations patient
    ordonnance.append("PATIENT(E) :")
    ordonnance.append("")
    ordonnance.append(f"Nom : [À COMPLÉTER]")
    ordonnance.append(f"Prénom : [À COMPLÉTER]")
    if f.get("age"):
        ordonnance.append(f"Âge : {f['age']} ans")
    else:
        ordonnance.append(f"Âge : [À COMPLÉTER]")
    
    if f.get("sexe"):
        sexe_txt = "Féminin" if f['sexe'] == 'f' else "Masculin"
        ordonnance.append(f"Sexe : {sexe_txt}")
    else:
        ordonnance.append(f"Sexe : [À COMPLÉTER]")
    
    ordonnance.append(f"N° Sécurité Sociale : [À COMPLÉTER]")
    ordonnance.append("")
    ordonnance.append("-" * 80)
    ordonnance.append("")
    
    # Motif de consultation
    ordonnance.append("MOTIF DE CONSULTATION :")
    ordonnance.append("")
    ordonnance.append(f"{texte_initial}")
    ordonnance.append("")
    ordonnance.append("-" * 80)
    ordonnance.append("")
    
    # Éléments cliniques recueillis
    ordonnance.append("ÉLÉMENTS CLINIQUES RECUEILLIS :")
    ordonnance.append("")
    
    # Grossesse si applicable
    if f.get("grossesse") is True and f.get("sexe") == "f":
        gs = f.get("grossesse_sem") or "durée non précisée"
        if isinstance(gs, int):
            ordonnance.append(f"• Grossesse en cours : {gs} semaines d'aménorrhée")
        else:
            ordonnance.append(f"• Grossesse en cours : {gs}")
    
    # Signes cliniques et antécédents
    signes_cliniques = []
    if f.get("fievre"):
        signes_cliniques.append("Syndrome fébrile")
    if f.get("brutale"):
        signes_cliniques.append("Installation brutale (céphalée en coup de tonnerre)")
    if f.get("deficit"):
        signes_cliniques.append("Déficit moteur ou sensitif")
    if f.get("vertige"):
        signes_cliniques.append("Vertige")
    if f.get("oncologique"):
        signes_cliniques.append("Antécédent oncologique")
    if f.get("chirurgie"):
        signes_cliniques.append("Chirurgie récente (<6 semaines) avec matériel")
    if f.get("pacemaker"):
        signes_cliniques.append("Porteur de pacemaker")
    if f.get("claustrophobie"):
        signes_cliniques.append("Claustrophobie")
    
    if signes_cliniques:
        for signe in signes_cliniques:
            ordonnance.append(f"• {signe}")
    else:
        ordonnance.append("• Pas de signe de gravité identifié")
    
    ordonnance.append("")
    ordonnance.append("-" * 80)
    ordonnance.append("")
    
    # Raisonnement clinique / Arbre décisionnel
    ordonnance.append("RAISONNEMENT CLINIQUE ET ARBRE DÉCISIONNEL :")
    ordonnance.append("")
    
    # Analyse de la situation
    ordonnance.append("Analyse de la situation :")
    if f["fievre"] or f["brutale"] or f["deficit"] or f["vertige"]:
        ordonnance.append("• Présence de critères d'urgence :")
        if f["fievre"]:
            ordonnance.append("  - Céphalée fébrile → risque de méningite ou d'infection du SNC")
        if f["brutale"]:
            ordonnance.append("  - Installation brutale → risque d'hémorragie méningée")
        if f["deficit"]:
            ordonnance.append("  - Déficit neurologique → risque d'AVC ou de lésion focale")
        if f["vertige"]:
            ordonnance.append("  - Vertige → exploration neurologique nécessaire")
        ordonnance.append("  → Indication à une imagerie en urgence")
    elif f["oncologique"]:
        ordonnance.append("• Contexte oncologique → surveillance des métastases cérébrales")
    elif f["grossesse"]:
        if f.get("grossesse_sem"):
            if f["grossesse_sem"] < 4:
                ordonnance.append("• Grossesse < 4 semaines → contre-indication absolue au scanner")
            elif f["grossesse_sem"] < 12:
                ordonnance.append("• Grossesse < 12 semaines → scanner uniquement si urgence vitale")
                ordonnance.append("• IRM contre-indiquée au 1er trimestre")
            else:
                ordonnance.append("• Grossesse > 12 semaines → imagerie possible avec précautions")
    
    ordonnance.append("")
    ordonnance.append("Choix de l'examen d'imagerie :")
    ordonnance.append(f"{decision}")
    ordonnance.append("")
    ordonnance.append("-" * 80)
    ordonnance.append("")
    
    # Prescription
    ordonnance.append("PRESCRIPTION :")
    ordonnance.append("")
    
    # Déterminer le type d'examen prescrit en fonction des données structurées
    # Vérifier d'abord les contre-indications absolues
    if f.get("grossesse") and f.get("grossesse_sem"):
        if f["grossesse_sem"] < 4:
            # Grossesse < 4 semaines : contre-indication absolue au scanner, IRM aussi
            ordonnance.append("⚠️  AUCUN EXAMEN D'IMAGERIE RECOMMANDÉ")
            ordonnance.append("    Grossesse < 4 semaines : contre-indication au scanner")
            ordonnance.append("    IRM contre-indiquée au 1er trimestre")
            ordonnance.append("    → Surveillance clinique et différer l'imagerie si possible")
        elif f["grossesse_sem"] < 12 and not (f["fievre"] or f["brutale"] or f["deficit"]):
            # Grossesse < 12 semaines SANS urgence
            ordonnance.append("⚠️  IMAGERIE DIFFÉRÉE RECOMMANDÉE")
            ordonnance.append("    Grossesse < 12 semaines sans critère d'urgence vitale")
            ordonnance.append("    Scanner uniquement si urgence vitale (non applicable ici)")
            ordonnance.append("    IRM contre-indiquée au 1er trimestre")
            ordonnance.append("    → Réévaluation après le 1er trimestre")
        elif f["grossesse_sem"] < 12 and (f["fievre"] or f["brutale"] or f["deficit"]):
            # Grossesse < 12 semaines AVEC urgence
            ordonnance.append("☐ SCANNER CÉRÉBRAL SANS INJECTION")
            ordonnance.append("    En URGENCE VITALE (après concertation)")
            ordonnance.append("    Indication : Critères d'urgence avec grossesse < 12 semaines")
            ordonnance.append("    ⚠️  Nécessite avis radiologique et accord de la patiente")
        else:
            # Grossesse >= 12 semaines
            if f["fievre"] or f["brutale"] or f["deficit"]:
                ordonnance.append("☐ SCANNER CÉRÉBRAL SANS INJECTION")
                ordonnance.append("    En urgence")
                ordonnance.append("    Indication : Céphalée aiguë avec critères de gravité")
            else:
                ordonnance.append("☐ IRM CÉRÉBRALE SANS INJECTION")
                ordonnance.append("    Indication : Céphalée sans critère d'urgence (grossesse)")
    elif f["fievre"] or f["brutale"] or f["deficit"] or f["vertige"]:
        # Urgence sans grossesse
        ordonnance.append("☐ SCANNER CÉRÉBRAL SANS INJECTION")
        ordonnance.append("    En urgence")
        ordonnance.append("    Indication : Céphalée aiguë avec critères de gravité")
    elif f["oncologique"]:
        ordonnance.append("☐ SCANNER CÉRÉBRAL AVEC INJECTION")
        ordonnance.append("    Indication : Contexte oncologique, recherche de métastases")
    elif "irm" in decision.lower() and "recommandée" in decision.lower():
        ordonnance.append("☐ IRM CÉRÉBRALE SANS INJECTION")
        ordonnance.append("    Indication : Céphalée sans critère d'urgence")
    else:
        ordonnance.append("☐ [EXAMEN D'IMAGERIE À PRÉCISER]")
        ordonnance.append("    → Consultation médicale pour évaluation")
    
    ordonnance.append("")
    ordonnance.append("-" * 80)
    ordonnance.append("")
    
    # Contre-indications et précautions
    ordonnance.append("CONTRE-INDICATIONS ET PRÉCAUTIONS :")
    ordonnance.append("")
    ordonnance.append(contraindications_text)
    ordonnance.append("")
    
    # Examens complémentaires si nécessaire
    examens_bio_ajoutes = False
    
    # Créatininémie si > 60 ans
    if f.get("age") and f["age"] > 60:
        ordonnance.append("")
        ordonnance.append("EXAMENS BIOLOGIQUES À PRÉVOIR :")
        ordonnance.append("")
        ordonnance.append("☐ Créatininémie + calcul de la clairance (DFG)")
        ordonnance.append("    (Avant injection de produit de contraste)")
        examens_bio_ajoutes = True
    
    # β-hCG UNIQUEMENT si femme < 50 ans ET grossesse NON confirmée
    if f.get("sexe") == "f" and (not f.get("age") or f["age"] < 50) and not f.get("grossesse"):
        if not examens_bio_ajoutes:
            ordonnance.append("")
            ordonnance.append("EXAMENS BIOLOGIQUES À PRÉVOIR :")
            ordonnance.append("")
        ordonnance.append("☐ β-hCG plasmatique (test de grossesse)")
        ordonnance.append("    (Avant tout examen irradiant)")
        examens_bio_ajoutes = True
    
    if examens_bio_ajoutes:
        ordonnance.append("")
    
    ordonnance.append("-" * 80)
    ordonnance.append("")
    
    # Pied de page
    ordonnance.append("Date et signature du praticien :")
    ordonnance.append("")
    ordonnance.append(f"Fait le {now.strftime('%d/%m/%Y')} à {now.strftime('%H:%M')}")
    ordonnance.append("")
    ordonnance.append("")
    ordonnance.append("Signature et cachet :")
    ordonnance.append("")
    ordonnance.append("")
    ordonnance.append("")
    ordonnance.append("=" * 80)
    ordonnance.append("")
    ordonnance.append("Cette ordonnance a été générée avec l'assistance d'un système d'aide à la décision")
    ordonnance.append("clinique. Elle doit être validée par le médecin prescripteur.")
    ordonnance.append("")
    
    return "\n".join(ordonnance)



def save_ordonnance(ordonnance_text, filename=None):
    """Enregistre l'ordonnance dans un fichier .txt (UTF-8) dans le dossier ordonnances/.
    Si `filename` est None ou vide, génère un nom basé sur la date/heure.
    Retourne le chemin du fichier créé.
    """
    import os
    # Obtenir le répertoire du script (source/) puis remonter au parent (v_arbre_d/)
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)  # v_arbre_d/
    ordonnances_dir = os.path.join(project_root, "ordonnances")
    os.makedirs(ordonnances_dir, exist_ok=True)

    if not filename:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"ordonnance_{ts}.txt"

    # Si l'utilisateur a fourni un nom simple, l'enregistrer dans ordonnances/
    if not os.path.isabs(filename):
        filename = os.path.join(ordonnances_dir, filename)

    with open(filename, "w", encoding="utf-8") as fh:
        fh.write(ordonnance_text)

    return os.path.abspath(filename)

def demander_oui_non(prompt):
    """Lecture directe d'une touche (o/n ou ← retour)."""
    print(prompt + " (o/n) : ", end="", flush=True)
    while True:
        key = readchar.readkey()
        if key.lower() == "o":
            print("o")
            return True
        elif key.lower() == "n":
            print("n")
            return False
        elif key == readchar.key.LEFT:
            print("\n⬅ Retour à la question précédente.")
            return "back"


def _load_system_entries(system):
    """Charge les entrées JSON pour un système donné depuis le dossier data/."""
    # Chemin relatif au projet
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    data_dir = os.path.join(project_root, "data")
    fname = os.path.join(data_dir, f"{system}.json")
    if not os.path.exists(fname):
        # essayer sans extension correspondante (fichiers complets)
        return []
    try:
        with open(fname, "r", encoding="utf-8") as fh:
            data = json.load(fh)
            return data
    except Exception:
        return []


def _normalize_text(txt):
    t_norm = unicodedata.normalize("NFKD", txt)
    t_norm = t_norm.encode("ascii", "ignore").decode("ascii").lower()
    return t_norm


def _normalize_key(s):
    # retourne une clé normalisée pour identifiants internes
    k = s.lower()
    k = re.sub(r"[^a-z0-9]+", "_", k)
    k = re.sub(r"_+", "_", k)
    return k.strip("_")


def _build_question_list_from_entries(entries):
    """Construit une liste ordonnée de questions (symptômes/indications) à partir des entrées JSON."""
    # Termes à exclure (noms d'examens, techniques, etc.)
    excluded_patterns = [
        r'^(ct|scanner|irm|mri|echo|radiographie|radio|angio|cxr|rx|us|doppler)',
        r'(injection|contraste|injecté|sans injection)',
        r'(face|profil|thorax|abdom|pelvien|cervical)',
        r'(1ère intention|2e intention|priorité)',
        r'(wells|genève|perc)',  # scores cliniques
        r'(hrct|tte|cta)',  # acronymes techniques
        r'(pré-ct|post)',
        r'(bilan|évaluation|recherche|triage|orientation|contrôle)',  # termes génériques
        r'(suspectée?|suspecté)',  # redondant avec le symptôme de base
        r'(anomalie|non caractérisé)',  # résultats d'examen
        r'(connu|écart)',  # qualificatifs non pertinents
        r'^suspi[_ ]',  # abréviation de suspicion
        r'(suivi de|suivi)',  # contexte de suivi
        r'(préopératoire|opératoire)',
        r'(visibilité|insuffisant)',
        r'^(htap|oacute|pid|ce)(\s|_|$)',  # acronymes médicaux seuls
        r'^suspicion$',  # "suspicion" seul sans contexte
        r'(oap|pid)\s',  # OAP/PID suivis d'espace
        r'^suspicion\s+(ce|de)\s',  # "suspicion CE", "suspicion de"
        r'^foie$',  # trop générique
    ]
    
    keys = {}
    for e in entries:
        # Ne garder que les symptômes cliniques
        vals = e.get("symptomes") or []
        for v in vals:
            k = _normalize_key(v)
            # Filtrer les termes techniques
            is_excluded = any(re.search(pat, k, re.IGNORECASE) for pat in excluded_patterns)
            if not is_excluded and k not in keys and len(k) > 2:
                keys[k] = v
    
    # Déduplication : si "toux chronique" existe, on garde pas "toux" seul
    # Trier par longueur décroissante pour privilégier les termes plus spécifiques
    sorted_keys = sorted(keys.keys(), key=lambda x: len(x), reverse=True)
    final_keys = {}
    for k in sorted_keys:
        # Vérifier si ce terme est un sous-ensemble d'un terme déjà retenu
        is_subset = False
        for existing_k in final_keys:
            # Si k est dans existing_k (ex: "toux" dans "toux chronique")
            if k in existing_k and k != existing_k:
                is_subset = True
                break
        if not is_subset:
            final_keys[k] = keys[k]
    
    # retourner une liste de tuples (key, libelle) triée alphabétiquement
    return [(k, final_keys[k]) for k in sorted(final_keys.keys())]


def _match_best_entry(entries, positives, patient_info):
    """Retourne l'entrée qui a le meilleur score de correspondance avec les réponses positives.
    positives: set of normalized keys
    patient_info: dictionnaire avec age, sexe, grossesse, etc.
    """
    best = None
    best_score = 0
    for e in entries:
        # Correspondance sur symptômes et indications
        items = set()
        for fld in ("symptomes", "indications_positives"):
            for v in (e.get(fld) or []):
                items.add(_normalize_key(v))
        if not items:
            continue
        score = len(items & positives)
        
        # Pénalité si des indications négatives sont présentes dans les positives
        neg_items = set()
        for v in (e.get("indications_negatives") or []):
            neg_items.add(_normalize_key(v))
        if neg_items & positives:
            score -= len(neg_items & positives) * 2  # Pénalité forte
        
        # Bonus si la population correspond (priorité à la détection automatique)
        populations = e.get("populations") or []
        detected_population = patient_info.get("population")
        if detected_population and detected_population in populations:
            score += 1.0  # Bonus fort si population détectée correspond
        elif patient_info.get("age"):  # Fallback sur l'âge si population non détectée
            age = patient_info["age"]
            if age < 18 and "enfant" in populations:
                score += 0.5
            elif 18 <= age < 65 and "adulte" in populations:
                score += 0.5
            elif age >= 65 and "personne_agee" in populations:
                score += 0.5
        
        if patient_info.get("sexe") == "f" and "femme" in populations:
            score += 0.3
        if patient_info.get("grossesse") and "enceinte" in populations:
            score += 2.0  # Bonus très fort pour grossesse (prioritaire sur adulte)
        
        if score > best_score:
            best_score = score
            best = e
    return best, best_score


def _is_question_redundant(question_key, question_label, patient_info, answers):
    """Vérifie si une question est redondante ou non pertinente.
    
    Args:
        question_key: Clé normalisée de la question
        question_label: Libellé original de la question
        patient_info: Dictionnaire des infos patient (age, sexe, etc.)
        answers: Réponses déjà données
    
    Returns:
        True si la question doit être filtrée (redondante/non pertinente)
    """
    label_lower = question_label.lower()
    
    # Filtrer questions sur l'âge si l'âge est déjà détecté
    if patient_info.get("age") is not None:
        age = patient_info["age"]
        # Questions de type "âge ≥ X ans" ou "âge < X ans"
        if re.search(r'âge.*?\d+.*?ans', label_lower):
            # Extraire le seuil d'âge de la question
            age_match = re.search(r'(\d+).*?ans', label_lower)
            if age_match:
                threshold = int(age_match.group(1))
                # Déterminer automatiquement la réponse
                if '≥' in label_lower or '>=' in label_lower or 'sup' in label_lower:
                    auto_answer = age >= threshold
                elif '<' in label_lower or 'inf' in label_lower:
                    auto_answer = age < threshold
                else:
                    return False
                # Ajouter la réponse automatique et filtrer la question
                answers[question_key] = auto_answer
                return True
    
    # Filtrer questions techniques/procédurales (non cliniques)
    technical_patterns = [
        r'irm.*?contre[- ]?indiquée',
        r'irm.*?indisponible',
        r'ponction.*?cytologique',
        r'exploration.*?chaîr?nière',
        r'gcs.*?<',  # Glasgow Coma Scale
        r'aidée?.*?par.*?us',
        r'évaluation.*?secondaire',
        r'hors.*?phase.*?aiguë',
        r'discordance.*?clinique.*?scanner',
        r'zones.*?suspectes.*?radiographies',
        r'lésions.*?osseuses.*?risque.*?vasculaire',
        r'règles.*?nexus',
        r'règles.*?canadian',
        r'aggravation.*?scanner.*?initial',
        r'diagnostic.*?de.*?craniosténose',
        r'avis.*?neurochirurgical.*?préalable',
        r'bilan.*?préopératoire',
        r'réévaluation.*?clinique.*?j\d+',
        r'surveillance.*?clinique.*?non.*?possible',
        r'exploration.*?craniosténose',
        r'scanner.*?après.*?avis.*?orl',  # Procédural
        r'orientation.*?topographique.*?étiologique',  # Jargon technique
        r'atteinte.*?canal.*?carotidien',  # Trop spécialisé
    ]
    
    for pattern in technical_patterns:
        if re.search(pattern, label_lower):
            return True
    
    # Filtrer questions pédiatriques pour adultes
    if patient_info.get("population") in ("adulte", "personne_agee"):
        pediatric_patterns = [
            r'craniosténose',
            r'fontanelle',
            r'transfontanell',
            r'périmètre.*?crânien',
            r'macrocrânie',
        ]
        for pattern in pediatric_patterns:
            if re.search(pattern, label_lower):
                answers[question_key] = False
                return True
    
    # Filtrer questions hors contexte
    out_of_context_patterns = [
        r'lésions.*?salivaires',
        r'kystes.*?congénitaux',
        r'glandes.*?salivaires',
    ]
    
    for pattern in out_of_context_patterns:
        if re.search(pattern, label_lower):
            return True
    
    # Filtrer questions trop vagues ou incompréhensibles
    vague_patterns = [
        r'^récentes?\s*/\s*inhabituelles?\s*\?\s*$',
        r'^tumorale\s*\?\s*$',
        r'^inflammatoire\s*\?\s*$',
        r'^infection\s*\?\s*$',  # Trop vague seul
        r'critères.*?majeurs.*?listés',
        r'critères.*?mineurs.*?selon',
        r'anomalies.*?à.*?l.*?examen.*?ou.*?contexte',
        r'^suspicion.*?fracture\s*\?\s*$',  # Sans contexte traumatique explicite
    ]
    
    for pattern in vague_patterns:
        if re.search(pattern, label_lower.strip()):
            return True
    
    return False


def chatbot_from_json(system):
    """Générique : interaction à partir d'un fichier JSON (`thorax` ou `digestif`)."""
    print(f"\nAIDE À LA PRESCRIPTION ({system})\n")

    texte = input("Médecin : ").strip()
    f = analyse_texte_medical(texte)

    if f["age"]:
        print(f"Âge détecté : {f['age']} ans")
    if f.get("population"):
        population_labels = {
            "enfant": "Enfant",
            "adulte": "Adulte",
            "personne_agee": "Personne âgée"
        }
        print(f"Population détectée : {population_labels.get(f['population'], f['population'])}")
    if f["sexe"]:
        print(f"Sexe détecté : {'femme' if f['sexe']=='f' else 'homme'}")

    entries = _load_system_entries(system)
    if not entries:
        print("Aucune donnée JSON trouvée pour ce système. Annulation.")
        return

    # Vérifier d'abord si des critères d'urgence immédiate sont présents (pour céphalées notamment)
    # Critères d'urgence : fièvre / brutale / déficit moteur pour les céphalées
    urgent_criteria = {"fievre": f.get("fievre"), "brutale": f.get("brutale"), "deficit": f.get("deficit")}
    if system == "cephalees" and any(urgent_criteria.values()):
        print("\nORIENTATION URGENTE :")
        print("  → Présence de critère(s) d'urgence (fébrile / installation brutale / déficit moteur).")
        print("  → Adresser le patient aux urgences sans délai.")
        # Pas d'examen à ce stade : passer des flags pour éviter remarques inutiles
        no_exam = {"ionisant": False, "requires_contrast": False}
        afficher_contraindications(f, no_exam)
        return

    # pré-remplir à partir du texte libre
    t_norm = _normalize_text(texte)
    answers = {}
    
    # Extraire tous les symptômes possibles avec leurs labels originaux
    all_symptoms_map = {}  # key -> original label
    for e in entries:
        for s in (e.get("symptomes") or []):
            key = _normalize_key(s)
            all_symptoms_map[key] = s
    
    # Pré-remplir automatiquement depuis le texte avec fuzzy matching
    for key, original_label in all_symptoms_map.items():
        # Utiliser fuzzy matching pour détecter le symptôme
        matched, score = _fuzzy_match_symptom(t_norm, original_label)
        answers[key] = matched

    # Construire l'ensemble initial des réponses positives
    positives = {k for k, v in answers.items() if v}
    
    # Filtrer les entrées candidates basées sur les réponses actuelles
    def get_relevant_entries():
        if not positives:
            return entries
        relevant = []
        for e in entries:
            symptoms = set(_normalize_key(s) for s in (e.get("symptomes") or []))
            # Garder l'entrée si elle partage au moins 1 symptôme avec les réponses positives
            if symptoms & positives:
                relevant.append(e)
        return relevant if relevant else entries
    
    # Questionnaire interactif dirigé
    max_iterations = 20  # Limite de sécurité
    iteration = 0
    
    while iteration < max_iterations:
        iteration += 1
        relevant_entries = get_relevant_entries()
        
        # Si une seule entrée correspond parfaitement, on arrête
        if len(relevant_entries) == 1:
            break
        
        # Si aucune entrée ne correspond, arrêter
        if not relevant_entries:
            break
        
        # Collecter tous les symptômes ET indications des entrées pertinentes
        all_relevant_symptoms = set()
        all_relevant_indications = set()
        
        for e in relevant_entries:
            for s in (e.get("symptomes") or []):
                all_relevant_symptoms.add(_normalize_key(s))
            for ind in (e.get("indications_positives") or []):
                all_relevant_indications.add(_normalize_key(ind))
        
        # Retirer les symptômes/indications déjà répondus
        unanswered_symptoms = all_relevant_symptoms - set(answers.keys())
        unanswered_indications = all_relevant_indications - set(answers.keys())
        
        # Filtrer les questions redondantes/non pertinentes
        # Récupérer les labels pour filtrage
        all_labels_map = {}
        for e in entries:
            for s in (e.get("symptomes") or []):
                all_labels_map[_normalize_key(s)] = s
            for ind in (e.get("indications_positives") or []):
                all_labels_map[_normalize_key(ind)] = ind
        
        # Filtrer les symptômes non répondus
        filtered_symptoms = set()
        for sym in unanswered_symptoms:
            label = all_labels_map.get(sym, sym)
            if not _is_question_redundant(sym, label, f, answers):
                filtered_symptoms.add(sym)
        
        # Filtrer les indications non répondues
        filtered_indications = set()
        for ind in unanswered_indications:
            label = all_labels_map.get(ind, ind)
            if not _is_question_redundant(ind, label, f, answers):
                filtered_indications.add(ind)
        
        # Prioriser les symptômes, puis les indications
        if filtered_symptoms:
            unanswered = filtered_symptoms
            source_field = "symptomes"
        elif filtered_indications:
            unanswered = filtered_indications
            source_field = "indications_positives"
        else:
            # Plus de questions pertinentes, on arrête
            break
        
        # Choisir l'item le plus discriminant (présent dans le plus d'entrées)
        item_counts = {}
        for item in unanswered:
            count = sum(1 for e in relevant_entries 
                       if item in set(_normalize_key(s) for s in (e.get(source_field) or [])))
            item_counts[item] = count
        
        # Trier par fréquence décroissante
        sorted_items = sorted(item_counts.items(), key=lambda x: x[1], reverse=True)
        
        if not sorted_items:
            break
        
        # Poser la question de l'item le plus discriminant
        next_item, _ = sorted_items[0]
        # Retrouver le label original
        original_label = None
        for e in relevant_entries:
            for s in (e.get(source_field) or []):
                if _normalize_key(s) == next_item:
                    original_label = s
                    break
            if original_label:
                break
        
        if not original_label:
            break
        
        r = demander_oui_non(f"{original_label} ?")
        if r == "back":
            # Retour arrière : retirer la dernière réponse
            if answers:
                last_key = list(answers.keys())[-1]
                del answers[last_key]
                positives = {k for k, v in answers.items() if v}
            continue
        
        answers[next_item] = r
        if r:
            positives.add(next_item)
        
        # Vérifier si un critère d'urgence est apparu pendant le questionnaire (céphalées)
        if system == "cephalees":
            # Critères d'urgence élargis : fièvre, brutale, déficit, hémorragie méningée, instabilité, altération conscience
            urgent_keywords = [
                "fievre", "febrile", "installation brutale", "coup de tonnerre",
                "deficit moteur", "deficit sensitif", "hemorragie meningee",
                "instabilite", "alteration conscience", "signes neuro"
            ]
            urgent_keys_norm = {_normalize_key(k) for k in urgent_keywords}
            if positives & urgent_keys_norm:
                print("\nORIENTATION URGENTE :")
                print("  → Critère d'urgence détecté pendant l'interrogatoire (fébrile / brutale / déficit moteur / signes neurologiques).")
                print("  → Adresser le patient aux urgences sans délai.")
                no_exam = {"ionisant": False, "requires_contrast": False}
                afficher_contraindications(f, no_exam)
                return
        
        # Si on a suffisamment d'informations (3+ items positifs), vérifier si on peut discriminer
        if len(positives) >= 3:
            scores = {}
            for e in relevant_entries:
                items = set()
                for fld in ("symptomes", "indications_positives"):
                    for v in (e.get(fld) or []):
                        items.add(_normalize_key(v))
                scores[e['id']] = len(items & positives)
            
            if scores:
                max_score = max(scores.values())
                top_entries = [eid for eid, score in scores.items() if score == max_score]
                if len(top_entries) == 1:
                    # Une seule entrée domine, on arrête
                    break

    # Construire l'ensemble final des réponses positives
    positives = {k for k, v in answers.items() if v}

    # Tenir compte des variables classiques
    if f.get("sexe") == "f" and f.get("grossesse") and not f.get("grossesse_sem"):
        # demander la durée
        print("\nDurée de la grossesse :")
        raw = input("Nombre de semaines (laisser vide si inconnu) : ").strip()
        try:
            if raw:
                f["grossesse_sem"] = int(raw)
        except Exception:
            f["grossesse_sem"] = None

    # Sélectionner la meilleure entrée
    best, score = _match_best_entry(entries, positives, f)

    decision_text = ""
    if best and score > 0:
        # Conserver le libellé modalité et résumé
        decision_text = f"{best.get('modalite')} — {best.get('resume')}"
        # Gérer grossesse et ionisant
        if best.get('ionisant'):
            if f.get('grossesse'):
                gs = f.get('grossesse_sem')
                if gs and gs < GROSSESSE_EARLY_THRESHOLD:
                    decision_text = (
                        "Examen ionisant contre-indiqué en cas de grossesse < 4 semaines. "
                        "Privilégier alternatives non ionisantes ou concertation spécialisée."
                    )
                elif gs and gs < GROSSESSE_FIRST_TRIMESTER:
                    decision_text += " (Grossesse < 12 semaines : scanner uniquement en urgence vitale)"
        # ajout d'une note si contraste requis
        if best.get('requires_contrast'):
            decision_text += " (requiert injection de produit de contraste si indiqué)"
    else:
        decision_text = (
            "Aucun item spécifique de l'arbre décisionnel trouvé à partir des réponses. "
            "Considérer l'évaluation clinique complète et choisir l'examen adapté."
        )

    # Afficher synthèse
    print("\nSYNTHÈSE CLINIQUE")
    if f.get("sexe"):
        print(f"  Sexe : {'femme' if f['sexe']=='f' else 'homme'}")
    if f.get("age"):
        print(f"  Âge : {f['age']} ans")
    if f.get("sexe") == "f" and f.get("grossesse") and f.get("grossesse_sem"):
        print(f"  Grossesse : {f['grossesse_sem']} semaines")

    # lister réponses positives avec labels originaux
    if positives:
        print("  Symptômes/Éléments identifiés :")
        # Récupérer les labels depuis les entrées JSON (symptômes ET indications)
        all_labels = {}
        for e in entries:
            for fld in ("symptomes", "indications_positives"):
                for s in (e.get(fld) or []):
                    all_labels[_normalize_key(s)] = s
        
        # Filtrer les critères d'âge auto-répondus (ne pas les afficher comme symptômes)
        for p in positives:
            original_label = all_labels.get(p, p)
            label_lower = original_label.lower()
            # Ne pas afficher les critères d'âge automatiques
            if re.search(r'âge.*?(\d+|<|>|≥|≤).*?(ans|mois)', label_lower):
                continue
            print(f"    • {original_label}")
    else:
        print("  - Aucun symptôme / élément positif identifié")

    print("\nRECOMMANDATION FINALE")
    print(decision_text)
    afficher_contraindications(f, best)

    # proposer sauvegarde rapport + ordonnance
    contraindications_text = get_contraindications_text(f, best)
    ordonnance_text = generer_ordonnance(f, texte, decision_text, contraindications_text)

    

    print("\n")
    if demander_oui_non("Voulez-vous générer l'ordonnance médicale"):
        fname_ordonnance = input("Nom de l'ordonnance (laisser vide pour générer automatiquement) : ").strip()
        saved_ordonnance = save_ordonnance(ordonnance_text, fname_ordonnance if fname_ordonnance else None)
        print(f"Ordonnance enregistrée : {saved_ordonnance}")
        print("\n⚠️  IMPORTANT : Cette ordonnance doit être revue et validée par le médecin prescripteur.")

# fonction principale -> affiche dans le terminal et ouvre une input box
if __name__ == "__main__":
    # Proposer le choix du système au démarrage
    print("Sélectionnez le système à évaluer :")
    print("1) Céphalées")
    print("2) Thorax")
    print("3) Système digestif")
    choix = input("Choix (1/2/3) : ").strip()
    if choix == "1":
        chatbot_from_json('cephalees')
    elif choix == "2":
        chatbot_from_json('thorax')
    elif choix == "3":
        chatbot_from_json('digestif')
    else:
        print("Choix invalide. Lancement par défaut du module céphalées.")
        chatbot_from_json('cephalees')